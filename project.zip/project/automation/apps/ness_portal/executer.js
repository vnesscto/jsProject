import NessPortal from "./nessportal.js";
import CommonOps from '../../infrastructure/commonops.js';

class Executer{
    async executSteps(steps){
        for(var i=0;i<steps.length; i++){
            switch(steps[i].page.toUpperCase()){
                case "LOGINPAGE":
                        switch(steps[i].method.name.toUpperCase()){
                            case "SETUSERNAME":
                                await NessPortal.LoginPage.setUserName(steps[i].method.parameters.param_1);
                                break;
                            case "SETPASSWORD":
                                await NessPortal.LoginPage.setPassword(steps[i].method.parameters.param_1);
                                break;
                            case "CLICKLOGIN":
                                await NessPortal.LoginPage.clickLogin();
                                break;
                        }
                        break;

                case "HOMEPAGE":
                    switch(steps[i].method.name.toUpperCase()){
                        case "CLICKLOGOUT":
                            await NessPortal.HomePage.clickLogout();
                            break;
                    }
                    break;   

                case "COMMONOPS":
                    switch(steps[i].method.name.toUpperCase()){
                        case "STARTCHROMEDRIVER":
                            await CommonOps.startChromeDriver(steps[i].method.parameters.param_1,steps[i].method.parameters.param_2);
                            break;
                        case "SETBROWSERURL":
                            await CommonOps.setBrowserUrl(steps[i].method.parameters.param_1);
                            break;
                    }
                    break;                                  
            }
        }
    }
}

export default new Executer();