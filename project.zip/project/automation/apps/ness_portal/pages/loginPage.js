import Repo from'../object_repository/objectrepository.js';
import seleniumhelper from '../../../infrastructure/seleniumhelper.js';

class LoginPage {

    async setUserName(value){
        let locator = Repo.getElement('LoginPage','user_name');
        await seleniumhelper.setText(locator, value);
    }

    async setPassword(value){
        let locator = Repo.getElement('LoginPage','password');
        await seleniumhelper.setText(locator, value);
    }

    async clickLogin(){
        try{
            let locator = Repo.getElement('LoginPage','click_login');
            await seleniumhelper.clickButton(locator);
        }catch (err){
            throw err;
        }
    }
}

export default new LoginPage();