import Repo from'../object_repository/objectrepository.js';
import seleniumhelper from '../../../infrastructure/seleniumhelper.js';

class HomePage{
    async clickLogout(){
        try{
            let locator = Repo.getElement('HomePage','Logout');
            await seleniumhelper.clickButton(locator);
        }catch (err){
            throw err;
        }
    }
}
export default new HomePage();