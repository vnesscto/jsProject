
import webdriver from 'selenium-webdriver';
const By = webdriver.By;

import { createRequire } from "module";
const require = createRequire(import.meta.url)
const repository = require('./elements.json');

class ObjectRepository{
    getElement(pageName,elementName){
        let element = repository[pageName].elements.find(el=>el.name === elementName);
        let by = element.by;
        switch(by){
            case 'id':
                return By.id(element.selector);
            case 'xpath':
                return By.xpath(element.selector);
        }
    }
}

export default new ObjectRepository();