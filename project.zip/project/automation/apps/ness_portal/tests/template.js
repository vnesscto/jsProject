describe('This is the describe block', async function () {
    this.timeout(50000);

    beforEach(()=>{
        //Enter action before test;
    });

    afterEach (()=>{
        //Enter action to be perform after test
    });

    it('POM test', ()=>{
        var baseurl = "https://home.ness-trch.co.il";
    }); 
});