import LoginPage from './pages/loginPage.js';
import HomePage from './pages/homePage.js';

class NessPortal {
    get LoginPage(){
        return LoginPage;
    }

    get HomePage(){
        return HomePage;
    }

    get HoursPage(){
    }
}

export default new NessPortal();