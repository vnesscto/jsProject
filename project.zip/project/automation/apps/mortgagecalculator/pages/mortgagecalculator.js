import { response } from 'express';
import webdriver from 'selenium-webdriver';
const By = webdriver.By;

class mortgagecalculator{
    async verifyBalances (){

        var driver = await new webdriver.Builder()
        .forBrowser('chrome')
        .build();

        var response = "";

        await driver.get ("https://www.mortgagecalculator.org/");
        
        try{
            let elements = await driver.findElements(By.xpath(`//*[@class ='highcharts-series highcharts-series-2 highcharts-column-series highcharts-tracker']//*[name() = 'rect']`));
            for(let e of elements) {
                const actions = driver.actions({async: true});
                await actions.move({origin:e}).perform();

                var aa = await driver.findElement(By.xpath("//*[name() = 'tspan' and text() = 'Balance']/following-sibling::*[1]"));
                var t = await aa.getAttribute("textContent");

                response = `${response == "" ? "" : response + " , "} "value": "${t}"`;
            }
            return  `{${response}}`;
        }
        finally{
            await driver.quit;
        }
    }

    async verifyPrincipal (){    
        var driver = await new webdriver.Builder()
        .forBrowser('chrome')
        .build();

        var response = "";

        await driver.get ("https://www.mortgagecalculator.org/");
        
        try{
            let elements = await driver.findElements(By.xpath(`//*[@class ='highcharts-series highcharts-series-2 highcharts-column-series highcharts-tracker']//*[name() = 'rect']`));
            for(let e of elements) {
                const actions = driver.actions({async: true});
                await actions.move({origin:e}).perform();

                var aa = await driver.findElement(By.xpath("//*[name() = 'tspan' and text() = 'Principal']/following-sibling::*[1]"));
                var t = await aa.getAttribute("textContent");

                response = `${response == "" ? "" : response + " , "} "value": "${t}"`;
            }
            return  `{${response}}`;
        }
        finally{
            await driver.quit;
        }
    }
}

export default new mortgagecalculator();